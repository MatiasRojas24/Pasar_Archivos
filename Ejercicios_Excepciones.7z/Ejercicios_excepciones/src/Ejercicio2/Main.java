package Ejercicio2;

public class Main {
    public static void main(String[] args) {
        Arrays a1 = new Arrays(3);
        try{
            a1.asignarValor(0,1);
            a1.asignarValor(1,2);
            a1.asignarValor(2,3);
            a1.asignarValor(3,4);
        } catch (IndexOutOfBoundsException e){
            System.out.println("Error: "+e.getMessage());
        }
    }
}
