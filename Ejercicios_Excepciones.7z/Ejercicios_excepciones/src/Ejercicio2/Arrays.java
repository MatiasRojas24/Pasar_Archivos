package Ejercicio2;

public class Arrays {
    private int[] array;

    public Arrays(int tam) {
        this.array = new int[tam];
    }

    public void asignarValor (int index, int valor) throws IndexOutOfBoundsException{
        if (index < 0 || index > array.length-1){
            throw new IndexOutOfBoundsException("El índice indicado está fuera del rango del array");
        }else{
            array[index] = valor;
        }
    }
}
