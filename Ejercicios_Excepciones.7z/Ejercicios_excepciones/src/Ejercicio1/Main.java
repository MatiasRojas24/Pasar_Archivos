package Ejercicio1;

public class Main {
    public static void main(String[] args) {
        Persona p1 = new Persona("Matías",-2);
        try {
            p1.imprimir();
        } catch (Exception c){
            System.out.println("Error: "+c.getMessage());
        }
    }
}
