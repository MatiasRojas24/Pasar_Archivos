<script>
		function mostrarDatos(){
			vnombre = document.getElementById("nombre").value;
			vapellido = document.getElementById("apellido").value;
			vnum = document.getElementById("num").value;
			voculto = document.getElementById("oculto").value;
			vurl = document.getElementById("url1").value;
			vpass = document.getElementById("pass").value;
		
			//Guardamos en una variable el nombre del campo lenguaje para trasnformarlo en objeto.
			var vlenguaje = document.getElementById("lengua");
			//Obtenemos del objeto a través del atributo selectedIndex el valor del objeto en esa posición
			var vLengua = vlenguaje.options[vlenguaje.selectedIndex].value;
		
			vgen = document.getElementsByName("genero").value;
			vbox1 = document.getElementById("box1").value;
			vbox2 = document.getElementById("box2").value;
			vbox3 = document.getElementById("box3").value;
		
			/* Imprime de los datos */		
			document.write("Los datos ingresados fueron: <br/>");
			document.write("Apellido: "+vapellido+"<br/>");
			document.write("Nombre: "+vnombre+"<br/>");
			document.write("Número: "+vnum+"<br/>");
			document.write("Tipo oculto: "+voculto+"<br/>");
			document.write("Tipo URL: "+vurl+"<br/>");
			document.write("Tipo Password: "+vpass+"<br/>");
			document.write("Elemento de Select: "+vLengua+"<br/>");
			document.write("Género: "+vgen+"<br/>");
			/*******************************************************/
		const radios = document.getElementsByName("genero");

				for (var i = 0; i <  radios.length; i++) {
				  if (radios[i].checked) {
					var vvgen = radios[i].value;
					 
					break;
				  }
				}
			document.write("Género **: "+vvgen+"<br/>"); 
			/**********************************************/
			document.write("Lenguaje 1: "+vbox1+"<br/>");
			document.write("Lenguaje 2: "+vbox2+"<br/>");
			document.write("Lenguaje 3: "+vbox3+"<br/>"); 
		
			document.write("<br/><strong>Gracias por sus datos</strong>");
			
		}
		</script>